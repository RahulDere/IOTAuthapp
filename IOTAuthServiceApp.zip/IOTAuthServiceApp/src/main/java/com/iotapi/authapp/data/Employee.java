package com.iotapi.authapp.data;

import java.util.ArrayList;
import java.util.List;

//@Entity
//@NoArgsConstructor
public class Employee {

		int Employeeid;
	     
	    String name;
	         
		public enum Department {
	        HR,
	        INFRASTRUCTURE,
	        PRODUCTDEVELOPMENT,
	        FINANCE,
	        EXECUTIVE;	
			
			private int departmentCode;

		    public int getdepartmentCode() {
		    	return departmentCode;
		    }
	    }
	    
		Department department;
		
	    int yearOfJoining;
	    
	    static List<Employee> employeeList = new ArrayList<Employee>();
	    
	    public Employee() {
	    	
	    }
	    
	    public Employee(int id, String name, int yearOfJoining, Department departName) 
	    {
	        this.Employeeid = id;
	        this.name = name;
	        this.yearOfJoining = yearOfJoining;	 
	        this.department = departName;
	    }
	     
	    public int getEmployeeid() 
	    {
	        return Employeeid;
	    }
	     
	    public String getName() 
	    {
	        return name;
	    }
	 	     
	    public int getYearOfJoining() 
	    {
	        return yearOfJoining;
	    }
	     
	    @Override
	    public String toString() 
	    {
	        return "Id : "+Employeeid
	                +", Name : "+name
	                +", Department : "+department.name()
	                +", Year Of Joining : "+yearOfJoining;
	    }	    
	    
	    
	    public Department getDepartment() {
			return department;
		}

		public void setDepartment(Department department) {
			this.department = department;
		}

		//this is only hardcoded database
	    public static List<Employee> getEmployeeList() {
	    	return employeeList;
		}
	
		public void setEmployeeList(List<Employee> employeeList) {
			Employee.employeeList = employeeList;
		}
	}
