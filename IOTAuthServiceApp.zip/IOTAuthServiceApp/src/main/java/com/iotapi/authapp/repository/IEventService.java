package com.iotapi.authapp.repository;

import org.springframework.security.access.annotation.Secured;

import com.iotapi.authapp.data.Events;

public interface IEventService {
	
	@Secured ({"ROLE_USER"})
	boolean authorizeAccess(long empid, long deviceId);
	@Secured ({"ROLE_USER"})
	void writeData(Events event);
	@Secured ({"ROLE_USER"})
	String validateData(Events event);
}
