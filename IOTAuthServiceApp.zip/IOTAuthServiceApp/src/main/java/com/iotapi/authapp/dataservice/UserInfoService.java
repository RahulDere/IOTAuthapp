package com.iotapi.authapp.dataservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.iotapi.authapp.data.Users;
import com.iotapi.authapp.repository.IUserInfoInterface;
@Service
public class UserInfoService implements IUserInfoInterface {
	
	@Value("${username}")
	private String username;
	
	@Value("${password}")
	private String password;
	
	public Users getActiveUser(String uName) {
		Users activeUserInfo = new Users();
		activeUserInfo.setUserName(uName);
		activeUserInfo.setPassword(password);
		activeUserInfo.setRole("ROLE_USER");
		activeUserInfo.setEnabled((short) 1);
		activeUserInfo.setCountry("US");
		activeUserInfo.setFullName("TestUser IOTUser");

		return activeUserInfo;
	}
}