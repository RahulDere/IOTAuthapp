package com.iotapi.authapp.data;

import java.util.ArrayList;
import java.util.List;

import com.iotapi.authapp.data.Employee.Department;
import com.iotapi.authapp.data.IOTDevices.IOTDeviceDoorType;

//@Entity
public class EmployeeAccess {

	public EmployeeAccess() {
		
	}
	//primary key in actual database.
	long employeeAccessId;
	IOTDeviceDoorType roomIOTDeviceType;
	Employee.Department departmentName;
	
	static List<EmployeeAccess> employeeAccesslist = new ArrayList<EmployeeAccess>();
		
	public EmployeeAccess(long employeeAccessId, IOTDeviceDoorType roomDeviceType, Department departmentName) {
		super();
		this.employeeAccessId = employeeAccessId;
		this.roomIOTDeviceType = roomDeviceType;
		this.departmentName = departmentName;
	}
	
	public long getEmployeeAccessId() {
		return employeeAccessId;
	}
	public void setEmployeeAccessId(long employeeAccessId) {
		this.employeeAccessId = employeeAccessId;
	}
	
	public IOTDeviceDoorType getroomIOTDeviceType() {
		return roomIOTDeviceType;
	}
	public void setRoomName(IOTDeviceDoorType roomDeviceType) {
		this.roomIOTDeviceType = roomDeviceType;
	}
	public Employee.Department getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(Employee.Department departmentName) {
		this.departmentName = departmentName;
	}
	
    //this is only hardcoded database
    public static List<EmployeeAccess> getemployeeAccesslist() {
   		return employeeAccesslist;
	}

	public void setEmployeeAccessList(List<EmployeeAccess> employeeaccessList) {
		this.employeeAccesslist = employeeaccessList;
	}
	
	
}
