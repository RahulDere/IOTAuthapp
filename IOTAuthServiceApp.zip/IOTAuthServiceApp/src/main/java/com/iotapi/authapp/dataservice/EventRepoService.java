package com.iotapi.authapp.dataservice;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.stereotype.Service;
import com.iotapi.authapp.data.Employee;
import com.iotapi.authapp.data.Employee.Department;
import com.iotapi.authapp.data.EmployeeAccess;
import com.iotapi.authapp.data.Events;
import com.iotapi.authapp.data.IOTDevices;
import com.iotapi.authapp.data.IOTDevices.IOTDeviceDoorType;
import com.iotapi.authapp.repository.IEventService;

@Service
public class EventRepoService implements IEventService {

	String[] HEADERS = { "EventId", "EventName", "DoorRoomID", "EmployeeID", "IOTdeviceId", "timestamp"};
	
	File IOTAuthDataFile = new File("IOTAuthData.csv"); 
	 
	@Override
	public boolean authorizeAccess(long empid, long deviceId) {
	
		//check employee data present and employee exists.
		//Employee employeeDB = new Employee();
		List<Employee> employeedataList = Employee.getEmployeeList();
   	 
		Optional<Employee> employeedtls = employeedataList.stream().filter(x -> x.getEmployeeid() == empid).findFirst();
		
		if(employeedtls.isPresent()) {
			//getting the department type for employee
			Department depart = employeedtls.get().getDepartment();
			
			//getting device id mapped to event occured.
			
			List<IOTDevices> IOTDevicesDBList = IOTDevices.getIOTDevicesList();
			Optional<IOTDevices> devicedtls = IOTDevicesDBList.stream().filter(y -> y.getIOTdeviceId() == deviceId).findFirst();
			
			if(devicedtls.isPresent()) {
				
				IOTDeviceDoorType devicetype = devicedtls.get().getDeviceDoorType();
				
				//if given employee present in given department
				List<EmployeeAccess> employeeAccessdataList = EmployeeAccess.getemployeeAccesslist();	
				
				Predicate<EmployeeAccess> isdepart = fr -> fr.getDepartmentName().name().equals(depart.name());
				Predicate<EmployeeAccess> isdevicetype = fr -> fr.getroomIOTDeviceType().name().equals(devicetype.name());
						
				boolean isAccessPresent = employeeAccessdataList.stream().anyMatch(isdevicetype.and(isdepart));
				
				return isAccessPresent;
			}
			
		}
		return false;
	}

	@Override
	public void writeData(Events event) {
		
		List<Events> values = new ArrayList<>();
		values.add(event);
		    
		try {
			
			createCSVFile(values);
			
		} catch (IOException e) {
		
			e.printStackTrace();
		}
				
	}
	//persists in CSV file.
	public void createCSVFile(List<Events> eventline) throws IOException {
		
		if (IOTAuthDataFile.length() == 0) {
			BufferedWriter writer = Files.newBufferedWriter(Paths.get("IOTAuthData.csv"), StandardOpenOption.CREATE,StandardOpenOption.APPEND);
			CSVPrinter aOut = new CSVPrinter(writer, CSVFormat.DEFAULT);
			aOut.printRecord(HEADERS);
			aOut.printRecord(eventline, LocalDateTime.now());
			aOut.close();
		} else {
			BufferedWriter writer = Files.newBufferedWriter(Paths.get("IOTAuthData.csv"), StandardOpenOption.APPEND);
			CSVPrinter dataOut = new CSVPrinter(writer, CSVFormat.DEFAULT);
			dataOut.printRecord(eventline, LocalDateTime.now());
			dataOut.close();
		}
	}

	@Override
	public String validateData(Events event) {
	
		return Validate(event);

	}
	
	private static String Validate(Events event)
    {
        //validate employee ID
        if (event.getEmployeeID() < 0 || event.getEmployeeID() == 0)
        {
            return "Employee Detail is not correct";
        }
        
		return "";
    }
       
}
