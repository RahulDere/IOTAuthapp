package com.iotapi.authapp.repository;

import com.iotapi.authapp.data.Users;

public interface IUserInfoInterface {
	//Method to get userDetails from DB.
	Users getActiveUser(String loginName);
}