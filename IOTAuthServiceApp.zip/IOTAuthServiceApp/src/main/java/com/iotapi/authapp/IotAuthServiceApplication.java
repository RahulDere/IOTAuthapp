package com.iotapi.authapp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import com.iotapi.authapp.data.Employee;
import com.iotapi.authapp.data.Employee.Department;
import com.iotapi.authapp.data.EmployeeAccess;
import com.iotapi.authapp.data.IOTDevices;

@SpringBootApplication
@EnableCaching(proxyTargetClass = true)
public class IotAuthServiceApplication {

	public static void main(String[] args) {
		
		//System.out.println("password: " encoder.encode("TestIOT@2"));
	
		SpringApplication.run(IotAuthServiceApplication.class, args);
		
		createEmployeeDatabase();
		
		createIOTDeviceDatabase();
		
		createEmployeeAccessDatabase();
	}

	private static void createEmployeeDatabase() {

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(new Employee(111, "Rahul Dere", 2011, Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(122, "Paul Niksui", 2015,Department.HR));
		employeeList.add(new Employee(133, "Martin Theron", 2012,Department.FINANCE));
		employeeList.add(new Employee(144, "Murali Gowda", 2014,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(155, "Nima Roy",2013,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(166, "Iqbal Hussain", 2016,Department.INFRASTRUCTURE));
		employeeList.add(new Employee(177, "Manu Sharma", 2010,Department.EXECUTIVE));
		employeeList.add(new Employee(188, "Wang Liu", 	2015,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(199, "Amelia Zoe", 2016,Department.INFRASTRUCTURE));
		employeeList.add(new Employee(200, "Jaden Dough",2015,Department.EXECUTIVE));
		employeeList.add(new Employee(211, "Jasna Kaur", 2014,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(222, "Nitin Joshi", 2016,Department.FINANCE));
		employeeList.add(new Employee(233, "Jyothi Reddy",2013,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(244, "Nicolus Den", 2017,Department.INFRASTRUCTURE));
		employeeList.add(new Employee(255, "Ali Baig", 	2018,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(266, "Sanvi Pandey", 2015,Department.PRODUCTDEVELOPMENT));
		employeeList.add(new Employee(277, "Anuj Chettiar", 2012,Department.HR));
		
		Employee emp = new Employee();
		emp.setEmployeeList(employeeList);

	}
	
	private static void createIOTDeviceDatabase() {
		
		List<IOTDevices> IOTDeviceList = new ArrayList<IOTDevices>();
		IOTDeviceList.add(new IOTDevices(1, IOTDevices.IOTDeviceDoorType.ENTRANCE));
		IOTDeviceList.add(new IOTDevices(2, IOTDevices.IOTDeviceDoorType.CONFERENCE));
		IOTDeviceList.add(new IOTDevices(3, IOTDevices.IOTDeviceDoorType.SERVER));
		IOTDeviceList.add(new IOTDevices(4, IOTDevices.IOTDeviceDoorType.EXECUTIVECABIN));
		IOTDeviceList.add(new IOTDevices(5, IOTDevices.IOTDeviceDoorType.CAFE));
		
		IOTDevices iotdevice = new IOTDevices();
		iotdevice.setIOTDevicesList(IOTDeviceList);

	}
	
	//this is department and Access role information.
	private static void createEmployeeAccessDatabase() {
		      
		List<EmployeeAccess> employeeAccesslst = new ArrayList<EmployeeAccess>();
		employeeAccesslst.add(new EmployeeAccess(1, IOTDevices.IOTDeviceDoorType.ENTRANCE, Department.HR));
		employeeAccesslst.add(new EmployeeAccess(2, IOTDevices.IOTDeviceDoorType.ENTRANCE, Department.PRODUCTDEVELOPMENT));
		employeeAccesslst.add(new EmployeeAccess(3, IOTDevices.IOTDeviceDoorType.ENTRANCE, Department.INFRASTRUCTURE));
		employeeAccesslst.add(new EmployeeAccess(4, IOTDevices.IOTDeviceDoorType.ENTRANCE, Department.FINANCE));
		employeeAccesslst.add(new EmployeeAccess(5, IOTDevices.IOTDeviceDoorType.ENTRANCE, Department.EXECUTIVE));
		
		employeeAccesslst.add(new EmployeeAccess(6, IOTDevices.IOTDeviceDoorType.EXECUTIVECABIN, Department.EXECUTIVE));
		
		employeeAccesslst.add(new EmployeeAccess(7, IOTDevices.IOTDeviceDoorType.SERVER, Department.INFRASTRUCTURE));
		
		employeeAccesslst.add(new EmployeeAccess(8, IOTDevices.IOTDeviceDoorType.CAFE, Department.HR));
		employeeAccesslst.add(new EmployeeAccess(9, IOTDevices.IOTDeviceDoorType.CAFE, Department.PRODUCTDEVELOPMENT));
		employeeAccesslst.add(new EmployeeAccess(10, IOTDevices.IOTDeviceDoorType.CAFE, Department.INFRASTRUCTURE));
		employeeAccesslst.add(new EmployeeAccess(11, IOTDevices.IOTDeviceDoorType.CAFE, Department.FINANCE));
		employeeAccesslst.add(new EmployeeAccess(12, IOTDevices.IOTDeviceDoorType.CAFE, Department.EXECUTIVE));
		
		employeeAccesslst.add(new EmployeeAccess(13, IOTDevices.IOTDeviceDoorType.CONFERENCE, Department.HR));
		employeeAccesslst.add(new EmployeeAccess(14, IOTDevices.IOTDeviceDoorType.CONFERENCE, Department.PRODUCTDEVELOPMENT));
		employeeAccesslst.add(new EmployeeAccess(15, IOTDevices.IOTDeviceDoorType.CONFERENCE, Department.INFRASTRUCTURE));
		employeeAccesslst.add(new EmployeeAccess(16, IOTDevices.IOTDeviceDoorType.CONFERENCE, Department.EXECUTIVE));
			
		EmployeeAccess employeeAccess = new EmployeeAccess();
		employeeAccess.setEmployeeAccessList(employeeAccesslst);

	}
}
