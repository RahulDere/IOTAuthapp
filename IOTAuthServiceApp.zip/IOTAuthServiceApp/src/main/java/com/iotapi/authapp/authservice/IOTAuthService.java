package com.iotapi.authapp.authservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.iotapi.authapp.data.Events;
import com.iotapi.authapp.dataservice.EventRepoService;

@RestController
@RequestMapping("iotauthapi/v1")
public class IOTAuthService {

	@Autowired
	private EventRepoService eventRepositoryService;
	
	@PostMapping(path="/events", consumes = "application/json")
	public String WriteData(@RequestBody Events event) {	
		eventRepositoryService.writeData(event);	
		
		return HttpStatus.CREATED.name();
	}
	
	@GetMapping(path="/authorize/{empid}/iotdevice/{deviceid}", produces = "application/json")
	@ResponseBody
	public boolean authorizeAccess(@PathVariable("empid") long empid, @PathVariable("deviceid") long deviceId) {
		
		return eventRepositoryService.authorizeAccess(empid,deviceId);
	}
	
	@PostMapping(path="/validate", consumes = "application/json")
	public String validateData(@RequestBody Events event) {
		
		String errorMsg = eventRepositoryService.validateData(event);
		if(errorMsg.length() != 0) 
		   return HttpStatus.BAD_REQUEST.name();
		
		return HttpStatus.OK.name();
	}
	 

	
}
