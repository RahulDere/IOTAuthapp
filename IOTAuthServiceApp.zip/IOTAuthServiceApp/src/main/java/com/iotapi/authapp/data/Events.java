package com.iotapi.authapp.data;

public class Events {

	Long eventId;
	EventName eventName;
	
	public enum EventName {
        ENTER,
        EXIT;
    }
	
	long employeeID;	
	long iotDeviceTokenId; //identifier type
	
	public Long getEventId() {
		return eventId;
	}
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	public long getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(long employeeID) {
		this.employeeID = employeeID;
	}
	public long getiotDeviceTokenId() {
		return iotDeviceTokenId;
	}
	public void setiotDeviceTokenId(long iOTdeviceId) {
		this.iotDeviceTokenId = iOTdeviceId;
	}
	public EventName getEventName() {
		return eventName;
	}
	public void setEventName(EventName eventName) {
		this.eventName = eventName;
	}
	
	@Override
    public String toString() 
    {
        return "Id : "+ eventId
                +", EmployeeID : "+ employeeID
                +", iotDeviceTokenId " + iotDeviceTokenId
                +", Event Name : "+ eventName;
    }	 
	
	
}
