package com.iotapi.authapp.data;

import java.util.ArrayList;
import java.util.List;

//@Entity
public class IOTDevices {
	
	public IOTDevices() {
		
	}
	
	//based on device token id ,I will identify the given door access.
	long IOTdeviceId;
	IOTDeviceDoorType deviceDoorType;
	
	public IOTDevices(int id, IOTDeviceDoorType devicetype) {
		 this.IOTdeviceId = id;
		 this.deviceDoorType = devicetype;
	}
	public long getIOTdeviceId() {
		return IOTdeviceId;
	}
	public void setIOTdeviceId(long iOTdeviceId) {
		IOTdeviceId = iOTdeviceId;
	}
		
	public IOTDeviceDoorType getDeviceDoorType() {
		return deviceDoorType;
	}
	public void setDeviceDoorType(IOTDeviceDoorType deviceDoorType) {
		this.deviceDoorType = deviceDoorType;
	}

	static List<IOTDevices> IOTDevicesList = new ArrayList<IOTDevices>();
	//this will map to building door.
	public enum IOTDeviceDoorType {
        ENTRANCE,
        SERVER,
		CAFE,
		CONFERENCE,
		EXECUTIVECABIN;
    }

	public static List<IOTDevices> getIOTDevicesList() {
		return IOTDevicesList;
	}
	public void setIOTDevicesList(List<IOTDevices> iOTDevicesList) {
		IOTDevicesList = iOTDevicesList;
	}
	
	
}
